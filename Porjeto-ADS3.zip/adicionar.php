<?php
require 'db/conexao.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titulo = $_POST['titulo'];
    $autor = $_POST['autor'];
    $ano = $_POST['ano'];
    $status = $_POST['status'];

    $stmt = $conn->prepare("INSERT INTO livros (titulo, autor, ano, status) VALUES (?, ?, ?, ?)");
    $stmt->execute([$titulo, $autor, $ano, $status]);

    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Adicionar Livro</title>
</head>
<body>
    <h1>Adicionar Livro</h1>
    <form method="POST">
        <label>Título:</label>
        <input type="text" name="titulo" required>
        <label>Autor:</label>
        <input type="text" name="autor" required>
        <label>Ano:</label>
        <input type="number" name="ano" required>
        <label>Status:</label>
        <select name="status" required>
            <option value="Lido">Lido</option>
            <option value="Não Lido">Não Lido</option>
        </select>
        <button type="submit">Adicionar</button>
    </form>
</body>
</html>
