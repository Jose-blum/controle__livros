<?php
require 'db/conexao.php';

$id = $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM livros WHERE id = ?");
$stmt->execute([$id]);
$livro = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titulo = $_POST['titulo'];
    $autor = $_POST['autor'];
    $ano = $_POST['ano'];
    $status = $_POST['status'];

    $stmt = $conn->prepare("UPDATE livros SET titulo = ?, autor = ?, ano = ?, status = ? WHERE id = ?");
    $stmt->execute([$titulo, $autor, $ano, $status, $id]);

    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Editar Livro</title>
</head>
<body>
    <h1>Editar Livro</h1>
    <form method="POST">
        <label>Título:</label>
        <input type="text" name="titulo" value="<?= $livro['titulo'] ?>" required>
        <label>Autor:</label>
        <input type="text" name="autor" value="<?= $livro['autor'] ?>" required>
        <label>Ano:</label>
        <input type="number" name="ano" value="<?= $livro['ano'] ?>" required>
        <label>Status:</label>
        <select name="status" required>
            <option value="Lido" <?= $livro['status'] === 'Lido' ? 'selected' : '' ?>>Lido</option>
            <option value="Não Lido" <?= $livro['status'] === 'Não Lido' ? 'selected' : '' ?>>Não Lido</option>
        </select>
        <button type="submit">Salvar</button>
    </form>
</body>
</html>
