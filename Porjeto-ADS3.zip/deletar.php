<?php
require 'db/conexao.php';

$id = $_GET['id'];
$stmt = $conn->prepare("DELETE FROM livros WHERE id = ?");
$stmt->execute([$id]);

header("Location: index.php");
exit();
?>
