<?php
$host = 'db4free.net'; // Alterar se estiver usando outro serviço
$user = 'joseblum'; // Substituir pelo seu usuário do DB4Free
$pass = 'adv10200';   // Substituir pela sua senha do DB4Free
$dbname = 'controle__livros'; // Nome do banco de dados criado

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Erro na conexão: " . $e->getMessage();
    exit();
}
?>
