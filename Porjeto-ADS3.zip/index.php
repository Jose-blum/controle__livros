<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
    <?php echo '<p>Hello World</p>'; ?> 

</html><?php
    require 'db/conexao.php';

    $stmt = $conn->query("SELECT * FROM livros ORDER BY id DESC");
    $livros = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <!DOCTYPE html>
    <html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style.css">
        <title>Controle de Livros</title>
    </head>
    <body>
        <h1>Controle de Livros</h1>
        <a href="adicionar.php" class="btn">Adicionar Livro</a>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Título</th>
                    <th>Autor</th>
                    <th>Ano</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($livros as $livro): ?>
                    <tr>
                        <td><?= $livro['id'] ?></td>
                        <td><?= $livro['titulo'] ?></td>
                        <td><?= $livro['autor'] ?></td>
                        <td><?= $livro['ano'] ?></td>
                        <td><?= $livro['status'] ?></td>
                        <td>
                            <a href="editar.php?id=<?= $livro['id'] ?>" class="btn">Editar</a>
                            <a href="deletar.php?id=<?= $livro['id'] ?>" class="btn btn-delete">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </body>
    </html>

